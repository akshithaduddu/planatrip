import React from "react";
const Header = ()=>{
    return(
        <div className="container">
            <div className="title">
            Plan a Trip
            </div>
        </div>
    )
}
export default Header;